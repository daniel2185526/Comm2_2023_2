#!/usr/bin/env python3
# -*- coding: utf-8 -*-

#
# SPDX-License-Identifier: GPL-3.0
#
# GNU Radio Python Flow Graph
# Title: top_block
# Author: radiogis_director
# GNU Radio version: 3.10.5.1

from packaging.version import Version as StrictVersion

if __name__ == '__main__':
    import ctypes
    import sys
    if sys.platform.startswith('linux'):
        try:
            x11 = ctypes.cdll.LoadLibrary('libX11.so')
            x11.XInitThreads()
        except:
            print("Warning: failed to XInitThreads()")

import os
import sys
sys.path.append(os.environ.get('GRC_HIER_PATH', os.path.expanduser('~/.grc_gnuradio')))

from PyQt5 import Qt
from gnuradio import qtgui
from gnuradio.filter import firdes
import sip
from b_demod_constelacion_cb import b_demod_constelacion_cb  # grc-generated hier_block
from b_meter_power_cc import b_meter_power_cc  # grc-generated hier_block
from b_u_de_M_PAM_bb import b_u_de_M_PAM_bb  # grc-generated hier_block
from gnuradio import analog
from gnuradio import blocks
import numpy
from gnuradio import digital
from gnuradio import filter
from gnuradio import gr
from gnuradio.fft import window
import signal
from argparse import ArgumentParser
from gnuradio.eng_arg import eng_float, intx
from gnuradio import eng_notation
from gnuradio.qtgui import Range, RangeWidget
from PyQt5 import QtCore
import E3TRadio
import math
import top_block_epy_block_0_0 as epy_block_0_0  # embedded python block
import top_block_epy_block_0_0_0 as epy_block_0_0_0  # embedded python block



from gnuradio import qtgui

class top_block(gr.top_block, Qt.QWidget):

    def __init__(self):
        gr.top_block.__init__(self, "top_block", catch_exceptions=True)
        Qt.QWidget.__init__(self)
        self.setWindowTitle("top_block")
        qtgui.util.check_set_qss()
        try:
            self.setWindowIcon(Qt.QIcon.fromTheme('gnuradio-grc'))
        except:
            pass
        self.top_scroll_layout = Qt.QVBoxLayout()
        self.setLayout(self.top_scroll_layout)
        self.top_scroll = Qt.QScrollArea()
        self.top_scroll.setFrameStyle(Qt.QFrame.NoFrame)
        self.top_scroll_layout.addWidget(self.top_scroll)
        self.top_scroll.setWidgetResizable(True)
        self.top_widget = Qt.QWidget()
        self.top_scroll.setWidget(self.top_widget)
        self.top_layout = Qt.QVBoxLayout(self.top_widget)
        self.top_grid_layout = Qt.QGridLayout()
        self.top_layout.addLayout(self.top_grid_layout)

        self.settings = Qt.QSettings("GNU Radio", "top_block")

        try:
            if StrictVersion(Qt.qVersion()) < StrictVersion("5.0.0"):
                self.restoreGeometry(self.settings.value("geometry").toByteArray())
            else:
                self.restoreGeometry(self.settings.value("geometry"))
        except:
            pass

        ##################################################
        # Variables
        ##################################################
        self.tabla_de_verdad_constelacion = tabla_de_verdad_constelacion = (1+0j, 0.707+0.707j, 0+1j, -0.707+0.707j, -1+0j, -0.707-0.707j, 0-1j, 0.707-0.707j)
        self.M = M = len(tabla_de_verdad_constelacion )
        self.bps = bps = int(math.log(M,2))
        self.Sps = Sps = 8
        self.Rs = Rs = 32000000
        self.samp_rate = samp_rate = Rs*Sps
        self.h = h = [1]*Sps
        self.delay_bits = delay_bits = bps
        self.Rb = Rb = Rs*bps
        self.N = N = 0.1

        ##################################################
        # Blocks
        ##################################################

        self._delay_bits_range = Range(0, 200, 1, bps, 200)
        self._delay_bits_win = RangeWidget(self._delay_bits_range, self.set_delay_bits, "delay_bits", "counter_slider", int, QtCore.Qt.Horizontal)
        self.top_layout.addWidget(self._delay_bits_win)
        self._N_range = Range(0, 10, 0.05, 0.1, 200)
        self._N_win = RangeWidget(self._N_range, self.set_N, "nivel ruido", "counter_slider", float, QtCore.Qt.Horizontal)
        self.top_layout.addWidget(self._N_win)
        self.qtgui_time_sink_x_1_0 = qtgui.time_sink_f(
            1024, #size
            samp_rate, #samp_rate
            "bits_comparacion", #name
            4, #number of inputs
            None # parent
        )
        self.qtgui_time_sink_x_1_0.set_update_time(0.10)
        self.qtgui_time_sink_x_1_0.set_y_axis(-1, 1)

        self.qtgui_time_sink_x_1_0.set_y_label('Amplitude', "")

        self.qtgui_time_sink_x_1_0.enable_tags(True)
        self.qtgui_time_sink_x_1_0.set_trigger_mode(qtgui.TRIG_MODE_FREE, qtgui.TRIG_SLOPE_POS, 0.0, 0, 0, "")
        self.qtgui_time_sink_x_1_0.enable_autoscale(False)
        self.qtgui_time_sink_x_1_0.enable_grid(False)
        self.qtgui_time_sink_x_1_0.enable_axis_labels(True)
        self.qtgui_time_sink_x_1_0.enable_control_panel(False)
        self.qtgui_time_sink_x_1_0.enable_stem_plot(True)


        labels = ['Bits Tx', 'Bits Rx', 'Resta Bits', 'BER instantaneo', 'Signal 5',
            'Signal 6', 'Signal 7', 'Signal 8', 'Signal 9', 'Signal 10']
        widths = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]
        colors = ['blue', 'red', 'green', 'black', 'cyan',
            'magenta', 'yellow', 'dark red', 'dark green', 'dark blue']
        alphas = [1.0, 1.0, 1.0, 1.0, 1.0,
            1.0, 1.0, 1.0, 1.0, 1.0]
        styles = [1, 4, 1, 1, 1,
            1, 1, 1, 1, 1]
        markers = [0, 0, -1, -1, -1,
            -1, -1, -1, -1, -1]


        for i in range(4):
            if len(labels[i]) == 0:
                self.qtgui_time_sink_x_1_0.set_line_label(i, "Data {0}".format(i))
            else:
                self.qtgui_time_sink_x_1_0.set_line_label(i, labels[i])
            self.qtgui_time_sink_x_1_0.set_line_width(i, widths[i])
            self.qtgui_time_sink_x_1_0.set_line_color(i, colors[i])
            self.qtgui_time_sink_x_1_0.set_line_style(i, styles[i])
            self.qtgui_time_sink_x_1_0.set_line_marker(i, markers[i])
            self.qtgui_time_sink_x_1_0.set_line_alpha(i, alphas[i])

        self._qtgui_time_sink_x_1_0_win = sip.wrapinstance(self.qtgui_time_sink_x_1_0.qwidget(), Qt.QWidget)
        self.top_layout.addWidget(self._qtgui_time_sink_x_1_0_win)
        self.qtgui_number_sink_3 = qtgui.number_sink(
            gr.sizeof_float,
            0,
            qtgui.NUM_GRAPH_HORIZ,
            2,
            None # parent
        )
        self.qtgui_number_sink_3.set_update_time(0.10)
        self.qtgui_number_sink_3.set_title("BER_instantaneo")

        labels = ['BER intantaneo ', 'BER promedio', '', '', '',
            '', '', '', '', '']
        units = ['[dB]', '', '', '', '',
            '', '', '', '', '']
        colors = [("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"),
            ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black")]
        factor = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]

        for i in range(2):
            self.qtgui_number_sink_3.set_min(i, -1)
            self.qtgui_number_sink_3.set_max(i, 1)
            self.qtgui_number_sink_3.set_color(i, colors[i][0], colors[i][1])
            if len(labels[i]) == 0:
                self.qtgui_number_sink_3.set_label(i, "Data {0}".format(i))
            else:
                self.qtgui_number_sink_3.set_label(i, labels[i])
            self.qtgui_number_sink_3.set_unit(i, units[i])
            self.qtgui_number_sink_3.set_factor(i, factor[i])

        self.qtgui_number_sink_3.enable_autoscale(False)
        self._qtgui_number_sink_3_win = sip.wrapinstance(self.qtgui_number_sink_3.qwidget(), Qt.QWidget)
        self.top_layout.addWidget(self._qtgui_number_sink_3_win)
        self.qtgui_number_sink_2 = qtgui.number_sink(
            gr.sizeof_float,
            0,
            qtgui.NUM_GRAPH_HORIZ,
            4,
            None # parent
        )
        self.qtgui_number_sink_2.set_update_time(0.10)
        self.qtgui_number_sink_2.set_title('Relacion señal a ruido')

        labels = ['SNR', 'SNR', 'Eb/No', 'Eb/No promm', '',
            '', '', '', '', '']
        units = ['[W]', '[dB]', '[dB]', 'db', '',
            '', '', '', '', '']
        colors = [("black", "black"), ("black", "black"), ("black", "red"), ("black", "black"), ("black", "black"),
            ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black"), ("black", "black")]
        factor = [1, 1, 1, 1, 1,
            1, 1, 1, 1, 1]

        for i in range(4):
            self.qtgui_number_sink_2.set_min(i, -1)
            self.qtgui_number_sink_2.set_max(i, 1)
            self.qtgui_number_sink_2.set_color(i, colors[i][0], colors[i][1])
            if len(labels[i]) == 0:
                self.qtgui_number_sink_2.set_label(i, "Data {0}".format(i))
            else:
                self.qtgui_number_sink_2.set_label(i, labels[i])
            self.qtgui_number_sink_2.set_unit(i, units[i])
            self.qtgui_number_sink_2.set_factor(i, factor[i])

        self.qtgui_number_sink_2.enable_autoscale(False)
        self._qtgui_number_sink_2_win = sip.wrapinstance(self.qtgui_number_sink_2.qwidget(), Qt.QWidget)
        self.top_layout.addWidget(self._qtgui_number_sink_2_win)
        self.interp_fir_filter_xxx_0_0 = filter.interp_fir_filter_ccf(1, h)
        self.interp_fir_filter_xxx_0_0.declare_sample_delay(0)
        self.interp_fir_filter_xxx_0 = filter.interp_fir_filter_ccf(Sps, h)
        self.interp_fir_filter_xxx_0.declare_sample_delay(0)
        self.epy_block_0_0_0 = epy_block_0_0_0.blk(Rs=Rs, Rb=Rb, Fs=samp_rate, k=bps)
        self.epy_block_0_0_0.set_block_alias("N=1")
        self.epy_block_0_0 = epy_block_0_0.blk()
        self.digital_chunks_to_symbols_xx_0 = digital.chunks_to_symbols_bc(tabla_de_verdad_constelacion, 1)
        self.blocks_packed_to_unpacked_xx_0 = blocks.packed_to_unpacked_bb(bps, gr.GR_MSB_FIRST)
        self.blocks_pack_k_bits_bb_0 = blocks.pack_k_bits_bb(8)
        self.blocks_null_sink_1 = blocks.null_sink(gr.sizeof_float*1)
        self.blocks_null_sink_0 = blocks.null_sink(gr.sizeof_char*1)
        self.blocks_multiply_const_vxx_2 = blocks.multiply_const_ff((-1))
        self.blocks_multiply_const_vxx_1 = blocks.multiply_const_ff((-1))
        self.blocks_multiply_const_vxx_0 = blocks.multiply_const_cc(1/Sps)
        self.blocks_moving_average_xx_0_0 = blocks.moving_average_ff(1000000, (1/1000000), 4000, 1)
        self.blocks_moving_average_xx_0 = blocks.moving_average_ff(1000000, (1/1000000), 4000, 1)
        self.blocks_divide_xx_0 = blocks.divide_ff(1)
        self.blocks_delay_1_0 = blocks.delay(gr.sizeof_float*1, delay_bits)
        self.blocks_delay_0 = blocks.delay(gr.sizeof_char*1, delay_bits)
        self.blocks_char_to_float_2 = blocks.char_to_float(1, 1)
        self.blocks_char_to_float_1 = blocks.char_to_float(1, 1)
        self.blocks_char_to_float_0_1 = blocks.char_to_float(1, 1)
        self.blocks_char_to_float_0_0_0 = blocks.char_to_float(1, 1)
        self.blocks_add_xx_2 = blocks.add_vff(1)
        self.blocks_add_xx_1 = blocks.add_vff(1)
        self.blocks_add_xx_0 = blocks.add_vcc(1)
        self.b_u_de_M_PAM_bb_0 = b_u_de_M_PAM_bb(
            M=M,
        )
        self.b_meter_power_cc_0_0 = b_meter_power_cc(
            G_prom=0.0001,
        )
        self.b_meter_power_cc_0 = b_meter_power_cc(
            G_prom=0.0001,
        )
        self.b_demod_constelacion_cb_0 = b_demod_constelacion_cb(
            Constelacion=tabla_de_verdad_constelacion,
        )
        self.analog_random_source_x_0 = blocks.vector_source_b(list(map(int, numpy.random.randint(0, 2, 1000))), True)
        self.analog_noise_source_x_0 = analog.noise_source_c(analog.GR_GAUSSIAN, N, 0)
        self.E3TRadio_diezmador_cc_0 = E3TRadio.diezmador_cc(8)


        ##################################################
        # Connections
        ##################################################
        self.connect((self.E3TRadio_diezmador_cc_0, 0), (self.b_demod_constelacion_cb_0, 0))
        self.connect((self.analog_noise_source_x_0, 0), (self.b_meter_power_cc_0_0, 0))
        self.connect((self.analog_noise_source_x_0, 0), (self.blocks_add_xx_0, 0))
        self.connect((self.analog_random_source_x_0, 0), (self.blocks_char_to_float_0_1, 0))
        self.connect((self.analog_random_source_x_0, 0), (self.blocks_delay_0, 0))
        self.connect((self.analog_random_source_x_0, 0), (self.blocks_pack_k_bits_bb_0, 0))
        self.connect((self.b_demod_constelacion_cb_0, 0), (self.b_u_de_M_PAM_bb_0, 0))
        self.connect((self.b_meter_power_cc_0, 1), (self.blocks_add_xx_1, 0))
        self.connect((self.b_meter_power_cc_0, 0), (self.blocks_divide_xx_0, 0))
        self.connect((self.b_meter_power_cc_0, 2), (self.blocks_null_sink_1, 0))
        self.connect((self.b_meter_power_cc_0_0, 0), (self.blocks_divide_xx_0, 1))
        self.connect((self.b_meter_power_cc_0_0, 1), (self.blocks_multiply_const_vxx_1, 0))
        self.connect((self.b_meter_power_cc_0_0, 2), (self.blocks_null_sink_1, 1))
        self.connect((self.b_u_de_M_PAM_bb_0, 0), (self.blocks_char_to_float_0_0_0, 0))
        self.connect((self.b_u_de_M_PAM_bb_0, 0), (self.blocks_char_to_float_2, 0))
        self.connect((self.b_u_de_M_PAM_bb_0, 0), (self.blocks_null_sink_0, 0))
        self.connect((self.blocks_add_xx_0, 0), (self.interp_fir_filter_xxx_0_0, 0))
        self.connect((self.blocks_add_xx_1, 0), (self.epy_block_0_0_0, 0))
        self.connect((self.blocks_add_xx_1, 0), (self.qtgui_number_sink_2, 1))
        self.connect((self.blocks_add_xx_2, 0), (self.epy_block_0_0, 0))
        self.connect((self.blocks_add_xx_2, 0), (self.qtgui_time_sink_x_1_0, 2))
        self.connect((self.blocks_char_to_float_0_0_0, 0), (self.qtgui_time_sink_x_1_0, 1))
        self.connect((self.blocks_char_to_float_0_1, 0), (self.blocks_delay_1_0, 0))
        self.connect((self.blocks_char_to_float_1, 0), (self.blocks_multiply_const_vxx_2, 0))
        self.connect((self.blocks_char_to_float_2, 0), (self.blocks_add_xx_2, 0))
        self.connect((self.blocks_delay_0, 0), (self.blocks_char_to_float_1, 0))
        self.connect((self.blocks_delay_1_0, 0), (self.qtgui_time_sink_x_1_0, 0))
        self.connect((self.blocks_divide_xx_0, 0), (self.qtgui_number_sink_2, 0))
        self.connect((self.blocks_moving_average_xx_0, 0), (self.qtgui_number_sink_3, 1))
        self.connect((self.blocks_moving_average_xx_0_0, 0), (self.qtgui_number_sink_2, 3))
        self.connect((self.blocks_multiply_const_vxx_0, 0), (self.E3TRadio_diezmador_cc_0, 0))
        self.connect((self.blocks_multiply_const_vxx_1, 0), (self.blocks_add_xx_1, 1))
        self.connect((self.blocks_multiply_const_vxx_2, 0), (self.blocks_add_xx_2, 1))
        self.connect((self.blocks_pack_k_bits_bb_0, 0), (self.blocks_packed_to_unpacked_xx_0, 0))
        self.connect((self.blocks_packed_to_unpacked_xx_0, 0), (self.digital_chunks_to_symbols_xx_0, 0))
        self.connect((self.digital_chunks_to_symbols_xx_0, 0), (self.interp_fir_filter_xxx_0, 0))
        self.connect((self.epy_block_0_0, 0), (self.blocks_moving_average_xx_0, 0))
        self.connect((self.epy_block_0_0, 0), (self.qtgui_number_sink_3, 0))
        self.connect((self.epy_block_0_0, 0), (self.qtgui_time_sink_x_1_0, 3))
        self.connect((self.epy_block_0_0_0, 0), (self.blocks_moving_average_xx_0_0, 0))
        self.connect((self.epy_block_0_0_0, 0), (self.qtgui_number_sink_2, 2))
        self.connect((self.interp_fir_filter_xxx_0, 0), (self.b_meter_power_cc_0, 0))
        self.connect((self.interp_fir_filter_xxx_0, 0), (self.blocks_add_xx_0, 1))
        self.connect((self.interp_fir_filter_xxx_0_0, 0), (self.blocks_multiply_const_vxx_0, 0))


    def closeEvent(self, event):
        self.settings = Qt.QSettings("GNU Radio", "top_block")
        self.settings.setValue("geometry", self.saveGeometry())
        self.stop()
        self.wait()

        event.accept()

    def get_tabla_de_verdad_constelacion(self):
        return self.tabla_de_verdad_constelacion

    def set_tabla_de_verdad_constelacion(self, tabla_de_verdad_constelacion):
        self.tabla_de_verdad_constelacion = tabla_de_verdad_constelacion
        self.set_M(len(self.tabla_de_verdad_constelacion ))
        self.b_demod_constelacion_cb_0.set_Constelacion(self.tabla_de_verdad_constelacion)
        self.digital_chunks_to_symbols_xx_0.set_symbol_table(self.tabla_de_verdad_constelacion)

    def get_M(self):
        return self.M

    def set_M(self, M):
        self.M = M
        self.set_bps(int(math.log(self.M,2)))
        self.b_u_de_M_PAM_bb_0.set_M(self.M)

    def get_bps(self):
        return self.bps

    def set_bps(self, bps):
        self.bps = bps
        self.set_Rb(self.Rs*self.bps)
        self.set_delay_bits(self.bps)
        self.epy_block_0_0_0.k = self.bps

    def get_Sps(self):
        return self.Sps

    def set_Sps(self, Sps):
        self.Sps = Sps
        self.set_h([1]*self.Sps)
        self.set_samp_rate(self.Rs*self.Sps)
        self.blocks_multiply_const_vxx_0.set_k(1/self.Sps)

    def get_Rs(self):
        return self.Rs

    def set_Rs(self, Rs):
        self.Rs = Rs
        self.set_Rb(self.Rs*self.bps)
        self.set_samp_rate(self.Rs*self.Sps)
        self.epy_block_0_0_0.Rs = self.Rs

    def get_samp_rate(self):
        return self.samp_rate

    def set_samp_rate(self, samp_rate):
        self.samp_rate = samp_rate
        self.epy_block_0_0_0.Fs = self.samp_rate
        self.qtgui_time_sink_x_1_0.set_samp_rate(self.samp_rate)

    def get_h(self):
        return self.h

    def set_h(self, h):
        self.h = h
        self.interp_fir_filter_xxx_0.set_taps(self.h)
        self.interp_fir_filter_xxx_0_0.set_taps(self.h)

    def get_delay_bits(self):
        return self.delay_bits

    def set_delay_bits(self, delay_bits):
        self.delay_bits = delay_bits
        self.blocks_delay_0.set_dly(int(self.delay_bits))
        self.blocks_delay_1_0.set_dly(int(self.delay_bits))

    def get_Rb(self):
        return self.Rb

    def set_Rb(self, Rb):
        self.Rb = Rb
        self.epy_block_0_0_0.Rb = self.Rb

    def get_N(self):
        return self.N

    def set_N(self, N):
        self.N = N
        self.analog_noise_source_x_0.set_amplitude(self.N)




def main(top_block_cls=top_block, options=None):

    if StrictVersion("4.5.0") <= StrictVersion(Qt.qVersion()) < StrictVersion("5.0.0"):
        style = gr.prefs().get_string('qtgui', 'style', 'raster')
        Qt.QApplication.setGraphicsSystem(style)
    qapp = Qt.QApplication(sys.argv)

    tb = top_block_cls()

    tb.start()

    tb.show()

    def sig_handler(sig=None, frame=None):
        tb.stop()
        tb.wait()

        Qt.QApplication.quit()

    signal.signal(signal.SIGINT, sig_handler)
    signal.signal(signal.SIGTERM, sig_handler)

    timer = Qt.QTimer()
    timer.start(500)
    timer.timeout.connect(lambda: None)

    qapp.exec_()

if __name__ == '__main__':
    main()
