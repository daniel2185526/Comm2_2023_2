
import numpy as np
from gnuradio import gr

class blk(gr.sync_block):  

    def __init__(self):  
        gr.sync_block.__init__(
            self,
            name="contador porcentaje de bits perdidos",   # will show up in GRC
            in_sig=[np.float32],
            out_sig=[np.float32]
        )
        self.acum_anterior = 0
        self.Ntotales = 0

     
    def work(self, input_items, output_items):
        x0 = input_items[0]  #Senial de entrada


        y0 = output_items[0] #Promedio de la senial
        #y0 = x0
        
        #Calculo del promedio
        N = len(x0)
        self.Ntotales = self.Ntotales + N

        suma = np.sum(np.abs(x0))
        y0[:] = suma/N

        #acumulado = self.acum_anterior + np.cumsum(np.multiply(x0, x0))
        #self.acum_anterior = acumulado[N-1]
        #y0[:] = acumulado/self.Ntotales



        
        return len(x0)
        
        
        
        
        
        
        
        
        
        
        
