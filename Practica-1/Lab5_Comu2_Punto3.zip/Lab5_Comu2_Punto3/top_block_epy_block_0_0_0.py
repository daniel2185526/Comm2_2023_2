
import numpy as np
import time
from gnuradio import gr

class blk(gr.sync_block):  

    def __init__(self, Rs=1.0, Rb=0.0, Fs=0.0, k=0.0):  
        gr.sync_block.__init__(
            self,
            name="Calculo_Eb_No",   # will show up in GRC
            in_sig=[np.float32],
            out_sig=[np.float32]
        )
        self.acum_anterior = 0
        self.Rs = Rs
        self.Rb = Rb
        self.Fs = Fs
        self.k = k   # bits por simbolo
     
    def work(self, input_items, output_items):
        x0 = input_items[0]  #in SNR en dB
        y0 = output_items[0] #salida
                
        #Calculo 
        N = len(x0)
        #y0[:] = x0 / self.Rs
        y0[:] = 10*np.log10((1/self.Rs)/(1/self.Fs)) - 10*np.log10(self.k) + x0
        #time.sleep(0.25)

        
        return len(x0)
        
        
        
        
        
        
        
        
        
        
        
